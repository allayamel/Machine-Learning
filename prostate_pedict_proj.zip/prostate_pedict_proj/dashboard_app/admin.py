from django.contrib import admin
from .models import Data

class DataAdmin(admin.ModelAdmin):
	list_display = ('perimeter', 'radius', 'texture', 'area', 'smoothness', 'compactness', 'symmetry', 'fractal_dimension')

admin.site.register(Data, DataAdmin)