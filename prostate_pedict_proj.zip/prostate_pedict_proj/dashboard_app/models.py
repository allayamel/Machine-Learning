from unicodedata import name
from decimal import Decimal
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from sklearn.tree import DecisionTreeClassifier
import joblib

class Data(models.Model):
    perimeter = models.PositiveBigIntegerField(validators=[MinValueValidator(50), MaxValueValidator(100)], null=True)
    radius = models.PositiveBigIntegerField(validators=[MinValueValidator(5), MaxValueValidator(30)], null=True)
    texture = models.PositiveBigIntegerField(validators=[MinValueValidator(10), MaxValueValidator(40)], null=True)
    area = models.PositiveBigIntegerField(validators=[MinValueValidator(900), MaxValueValidator(1000)], null=True)    
    smoothness = models.DecimalField(null=True,max_digits=13, decimal_places=2)
    compactness = models.DecimalField(null=True,max_digits=13, decimal_places=2)
    symmetry = models.DecimalField(null=True,max_digits=13, decimal_places=2)
    fractal_dimension = models.DecimalField(null=True,max_digits=13, decimal_places=2)
    predictions = models.CharField(max_length=100, blank=True)
    date = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        ml_model = joblib.load('ml_model/ml_Prostate_model.joblib')
        self.predictions = ml_model.predict([[self.perimeter, self.radius, self.texture, self.area, self.smoothness, self.compactness, self.symmetry, self.fractal_dimension]])
        return super().save(*args, **kwargs)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return self.perimeter
